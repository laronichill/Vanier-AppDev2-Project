package com.example.squidapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
