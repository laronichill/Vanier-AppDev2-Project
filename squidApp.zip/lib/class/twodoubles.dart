class Twodoubles{
  double num1;
  double num2;

  Twodoubles({required this.num1, required this.num2});
}